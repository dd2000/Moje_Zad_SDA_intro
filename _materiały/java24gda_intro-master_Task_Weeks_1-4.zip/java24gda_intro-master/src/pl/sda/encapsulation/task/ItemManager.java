package pl.sda.encapsulation.task;

public class ItemManager {
    ItemModel createShopItem(String title, String description, double price) {
        return new ItemModel();
    }
}

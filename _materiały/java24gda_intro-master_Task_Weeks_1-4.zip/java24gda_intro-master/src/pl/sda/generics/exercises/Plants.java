package pl.sda.generics.exercises;

public interface Plants {
    String getName();
}
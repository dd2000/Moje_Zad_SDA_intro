package pl.sda.generics.boxes;

public class Apple extends Fruit {
    public Apple(boolean rotten) {
        super(rotten);
    }
}

package pl.sda.generics.boxes;

public class Orange extends Fruit {
    public Orange(boolean rotten) {
        super(rotten);
    }
}

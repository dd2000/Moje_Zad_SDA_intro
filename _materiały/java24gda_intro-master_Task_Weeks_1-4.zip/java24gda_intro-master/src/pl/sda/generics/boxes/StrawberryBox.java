package pl.sda.generics.boxes;

public class StrawberryBox {
    private Strawberry strawberry;

    public StrawberryBox(Strawberry strawberry) {
        this.strawberry = strawberry;
    }

    public Strawberry getStrawberry() {
        return strawberry;
    }
}

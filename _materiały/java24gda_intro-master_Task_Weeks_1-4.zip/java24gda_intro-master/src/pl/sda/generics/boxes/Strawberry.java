package pl.sda.generics.boxes;

public class Strawberry extends Fruit {
    public Strawberry(boolean rotten) {
        super(rotten);
    }
}

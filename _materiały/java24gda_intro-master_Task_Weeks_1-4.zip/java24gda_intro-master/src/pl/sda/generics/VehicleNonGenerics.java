package pl.sda.generics;

public class VehicleNonGenerics {
    private Object obj;

    public Object get() {
        return obj;
    }

    public void set(Object obj) {
        this.obj = obj;
    }
}

package pl.sda.tasks.weekend2.coinpo.carfactory;

public class CarFactory {
    public static void main(String[] args) {
        Helpers helpers = new Helpers();

        helpers.showIntro();
    }
}

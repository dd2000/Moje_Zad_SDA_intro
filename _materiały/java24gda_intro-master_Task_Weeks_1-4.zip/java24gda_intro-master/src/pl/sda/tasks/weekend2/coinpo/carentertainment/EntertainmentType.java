package pl.sda.tasks.weekend2.coinpo.carentertainment;

public enum EntertainmentType {
    RADIO,
    STREAM
}

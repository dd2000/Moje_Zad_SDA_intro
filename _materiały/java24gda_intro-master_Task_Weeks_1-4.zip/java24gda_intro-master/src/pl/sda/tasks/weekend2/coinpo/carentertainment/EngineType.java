package pl.sda.tasks.weekend2.coinpo.carentertainment;

public enum EngineType {
    DIESEL,
    PETROL,
    OTHER
}

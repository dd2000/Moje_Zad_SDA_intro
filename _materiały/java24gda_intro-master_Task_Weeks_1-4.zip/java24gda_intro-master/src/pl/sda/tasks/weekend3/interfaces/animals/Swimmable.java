package pl.sda.tasks.weekend3.interfaces.animals;

public interface Swimmable {
    void swim();
}

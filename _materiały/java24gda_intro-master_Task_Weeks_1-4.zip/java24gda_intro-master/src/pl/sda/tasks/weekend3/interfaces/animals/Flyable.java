package pl.sda.tasks.weekend3.interfaces.animals;

public interface Flyable {
    void fly();
}

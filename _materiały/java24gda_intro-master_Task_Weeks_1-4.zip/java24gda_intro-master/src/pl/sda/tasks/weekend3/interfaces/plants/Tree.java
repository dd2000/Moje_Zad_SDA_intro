package pl.sda.tasks.weekend3.interfaces.plants;

public class Tree implements Plant {

    @Override
    public int getAge() {
        return 999;
    }

    @Override
    public String getName() {
        return "Bartek The Oak";
    }
}

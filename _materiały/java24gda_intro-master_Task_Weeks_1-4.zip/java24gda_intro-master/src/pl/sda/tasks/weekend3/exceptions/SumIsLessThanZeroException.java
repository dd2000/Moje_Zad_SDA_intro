package pl.sda.tasks.weekend3.exceptions;

/**
 * 5. Utwórz własny wyjątek, który będzie rzucany przez metodę do sumowania liczb z poprzedniego punktu, w momencie gdy suma będzie mniejsza od zera.
 */
public class SumIsLessThanZeroException extends RuntimeException {}

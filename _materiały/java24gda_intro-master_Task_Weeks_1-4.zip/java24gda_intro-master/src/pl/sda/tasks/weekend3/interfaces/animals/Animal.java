package pl.sda.tasks.weekend3.interfaces.animals;

public interface Animal extends Being {
    String getName();
    String speak();
}

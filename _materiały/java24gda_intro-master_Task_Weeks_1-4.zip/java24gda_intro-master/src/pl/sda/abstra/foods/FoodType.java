package pl.sda.abstra.foods;

public enum FoodType {
    MEAT,
    VEGETABLE
}

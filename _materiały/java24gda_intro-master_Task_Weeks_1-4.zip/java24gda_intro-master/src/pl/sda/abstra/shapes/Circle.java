package pl.sda.abstra.shapes;

public class Circle extends Shape {
    @Override
    public void draw() {
        System.out.println("DRAW: CIRCLE");
    }
}

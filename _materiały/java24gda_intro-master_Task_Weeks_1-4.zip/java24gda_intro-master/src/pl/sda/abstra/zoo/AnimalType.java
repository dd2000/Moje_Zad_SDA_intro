package pl.sda.abstra.zoo;

public enum AnimalType {
    MAMMAL,
    FISH,
    REPTILE,
    BIRD
}

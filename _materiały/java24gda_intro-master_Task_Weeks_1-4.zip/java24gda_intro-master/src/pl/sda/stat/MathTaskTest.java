package pl.sda.stat;

public class MathTaskTest {
    public static void main(String[] args) {
        // nie jesteśmy w stanie utworzyć obiektu klasy MathTask
//        MathTask mathTask = new MathTask();
    }
}

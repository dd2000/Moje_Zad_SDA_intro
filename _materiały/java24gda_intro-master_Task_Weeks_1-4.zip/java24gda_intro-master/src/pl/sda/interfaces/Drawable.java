package pl.sda.interfaces;

public interface Drawable {
    void draw();
}
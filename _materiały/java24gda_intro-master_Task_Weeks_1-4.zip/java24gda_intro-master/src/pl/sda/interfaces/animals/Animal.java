package pl.sda.interfaces.animals;

public interface Animal {
    String getName();
    String speak();
}

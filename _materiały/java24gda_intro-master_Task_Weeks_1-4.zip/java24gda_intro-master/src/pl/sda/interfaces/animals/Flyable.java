package pl.sda.interfaces.animals;

public interface Flyable {
    String fly();
}

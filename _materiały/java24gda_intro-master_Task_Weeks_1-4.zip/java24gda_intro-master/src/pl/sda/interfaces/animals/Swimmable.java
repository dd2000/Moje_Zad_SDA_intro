package pl.sda.interfaces.animals;

public interface Swimmable {
    String swim();
}
